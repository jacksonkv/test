#!/bin/bash
set -euo pipefail

security lock-keychain ~/Library/Keychains/electron-ci-secrets.keychain-db