# Thanks

The following people have contributed to Threema for Desktop through GitHub:

- [ljrk0] ([#6])

Thank you!

[ljrk0]: https://github.com/ljrk0
[#6]: https://github.com/threema-ch/threema-web-electron/pull/6
